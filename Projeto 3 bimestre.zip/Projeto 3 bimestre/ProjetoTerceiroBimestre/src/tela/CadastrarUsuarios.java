package tela;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import banco.FabricaConexao;
import dominio.Usuarios;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.border.EtchedBorder;
import javax.swing.ImageIcon;

public class CadastrarUsuarios extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldNome;
	private JTextField textFieldUsuario;
	private JTextField textFieldEmail;
	private JTextField textFieldTelefone;
	private JList listarUsuarios;
	private Usuarios usuarioEdicao;
	private JButton btnNewButtonCadastrar;
	private JPasswordField passwordFieldSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastrarUsuarios frame = new CadastrarUsuarios();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 */
	public CadastrarUsuarios() throws ClassNotFoundException, SQLException {
		setTitle("Cadastro de Aluno");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 575, 456);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(
				new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)),
				"Area de Cadastro", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel.setBounds(10, 11, 533, 149);
		contentPane.add(panel);
		panel.setLayout(null);

		textFieldNome = new JTextField();
		textFieldNome.setBounds(137, 62, 78, 20);
		panel.add(textFieldNome);
		textFieldNome.setColumns(10);

		textFieldUsuario = new JTextField();
		textFieldUsuario.setColumns(10);
		textFieldUsuario.setBounds(49, 62, 78, 20);
		panel.add(textFieldUsuario);

		textFieldEmail = new JTextField();
		textFieldEmail.setColumns(10);
		textFieldEmail.setBounds(225, 62, 78, 20);
		panel.add(textFieldEmail);

		textFieldTelefone = new JTextField();
		textFieldTelefone.setColumns(10);
		textFieldTelefone.setBounds(313, 62, 78, 20);
		panel.add(textFieldTelefone);

		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(137, 48, 58, 14);
		panel.add(lblNome);

		JLabel lblEmail = new JLabel("Email");
		lblEmail.setBounds(225, 48, 68, 14);
		panel.add(lblEmail);

		JLabel lblUsuario = new JLabel("Usuario");
		lblUsuario.setBounds(49, 48, 58, 14);
		panel.add(lblUsuario);

		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setBounds(313, 48, 56, 14);
		panel.add(lblTelefone);

		btnNewButtonCadastrar = new JButton("Cadastrar");
		btnNewButtonCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					cadastrarUsuario();
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButtonCadastrar.setBounds(193, 99, 135, 23);
		panel.add(btnNewButtonCadastrar);

		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setBounds(401, 48, 58, 14);
		panel.add(lblSenha);

		passwordFieldSenha = new JPasswordField();
		passwordFieldSenha.setBounds(401, 62, 78, 20);
		panel.add(passwordFieldSenha);

		JLabel lblNewLabel = new JLabel("CADASTRO DE USUARIO");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 16));
		lblNewLabel.setBounds(160, 22, 220, 14);
		panel.add(lblNewLabel);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 171, 533, 235);
		contentPane.add(panel_1);
		panel_1.setBorder(new TitledBorder(
				new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)),
				"Listagem de Usuarios", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 21, 258, 200);
		panel_1.add(scrollPane);

		listarUsuarios = new JList();
		scrollPane.setViewportView(listarUsuarios);

		JButton btnNewButtonExibir = new JButton("Exibir Dados");
		btnNewButtonExibir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Usuarios usuarioSelecionado = (Usuarios) listarUsuarios.getSelectedValue();

				String msg =  "Usuario: " + usuarioSelecionado.getUsuario() +
						     "\nNome: " + usuarioSelecionado.getNome() + 
						     "\nEmail: " + usuarioSelecionado.getEmail() + 
						     "\nTelefone: " + usuarioSelecionado.getTelefone() +
						     "\nSenha: " + usuarioSelecionado.getSenha();

				ExibirMensagem(msg);

			}
		});
		btnNewButtonExibir.setBounds(306, 46, 187, 27);
		panel_1.add(btnNewButtonExibir);

		JButton btnEditarDados = new JButton("Editar Dados");
		btnEditarDados.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				iniciarEdicaoUsuario();
			}
		});
		btnEditarDados.setBounds(306, 101, 187, 27);
		panel_1.add(btnEditarDados);

		JButton btnNewButtonRemover = new JButton("Remover");
		btnNewButtonRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					removerDados();
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButtonRemover.setBounds(306, 152, 187, 30);
		panel_1.add(btnNewButtonRemover);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(0, 0, 559, 416);
		contentPane.add(lblNewLabel_1);
		lblNewLabel_1.setIcon(new ImageIcon(CadastrarUsuarios.class.getResource("/imagem/beautiful-gradient-instagram.png")));

		atualizarListagem();
	}

	protected void removerDados() throws ClassNotFoundException, SQLException {

		if (listarUsuarios.getSelectedIndex() == -1) {
			exibirMensagemErro("Selecione um usuario");
		}

		usuarioEdicao = (Usuarios) listarUsuarios.getSelectedValue();

		Connection conexao = FabricaConexao.criarConexao();

		String sql = "DELETE FROM cadastroUsuarios WHERE ID = ?";

		PreparedStatement comando = conexao.prepareStatement(sql);

		comando.setInt(1, usuarioEdicao.getId());
		comando.executeUpdate();

		ExibirMensagem("Dados Removido");

		atualizarListagem();

		comando.close();
		conexao.close();

	}

	protected void iniciarEdicaoUsuario() {
		if (listarUsuarios.getSelectedIndex() == -1) {
			exibirMensagemErro("Selecione um usuaro");
		}

		usuarioEdicao = (Usuarios) listarUsuarios.getSelectedValue();
		textFieldNome.setText(usuarioEdicao.getNome());
		textFieldUsuario.setText(usuarioEdicao.getUsuario());
		textFieldEmail.setText(usuarioEdicao.getEmail());
		textFieldTelefone.setText(usuarioEdicao.getTelefone());
		passwordFieldSenha.setText(usuarioEdicao.getSenha());
		
		btnNewButtonCadastrar.setText("Editar Dados");

	}

	protected void ExibirMensagem(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Info", JOptionPane.INFORMATION_MESSAGE);

	}

	private void atualizarListagem() throws ClassNotFoundException, SQLException {

		Connection conexao = FabricaConexao.criarConexao();

		String sql = "SELECT * FROM cadastroUsuarios";

		PreparedStatement comando = conexao.prepareStatement(sql);

		ResultSet resultado = comando.executeQuery();

		List<Usuarios> usuariosCadastrados = new ArrayList<Usuarios>();

		while (resultado.next()) {
			Usuarios u = new Usuarios();

			u.setId(resultado.getInt("id"));
			u.setNome(resultado.getString("nome"));
			u.setUsuario(resultado.getString("usuario"));
			u.setEmail(resultado.getString("email"));
			u.setTelefone(resultado.getString("telefone"));
            u.setSenha(resultado.getString("senha"));
			
			usuariosCadastrados.add(u);
		}

		DefaultListModel<Usuarios> modelo = new DefaultListModel<>();

		for (int i = 0; i < usuariosCadastrados.size(); i++) {
			Usuarios a = usuariosCadastrados.get(i);
			modelo.addElement(a);
		}

		listarUsuarios.setModel(modelo);

		comando.close();
		conexao.close();

	}

	protected void cadastrarUsuario() throws ClassNotFoundException, SQLException {

		if (textFieldNome.getText() == null || textFieldNome.getText().isEmpty()) {
			exibirMensagemErro("Nome não pode ser vazio");
			return;
		}

		if (textFieldUsuario.getText() == null || textFieldUsuario.getText().isEmpty()) {
			exibirMensagemErro("Usuario não pode ser vazio");
			return;
		}

		if (textFieldEmail.getText() == null || textFieldEmail.getText().isEmpty()) {
			exibirMensagemErro("Email não pode ser vazio");
			return;
		}

		if (textFieldTelefone.getText() == null || textFieldTelefone.getText().isEmpty()) {
			exibirMensagemErro("Telefone não pode ser vazio");
			return;
		}
		if (passwordFieldSenha.getText() == null || passwordFieldSenha.getText().isEmpty()) {
			exibirMensagemErro("Senha não pode ser vazio");
			return;
		}

		if (btnNewButtonCadastrar.getText().equals("Cadastrar")) {

			Connection conexao = FabricaConexao.criarConexao();

			String sql = "INSERT INTO cadastroUsuarios (usuario, nome, email, telefone, senha) VALUES (?,?,?,?,?)";

			Usuarios u = new Usuarios();

			u.setNome(textFieldNome.getText());
			u.setUsuario(textFieldUsuario.getText());
			u.setEmail(textFieldEmail.getText());
			u.setTelefone(textFieldTelefone.getText());
            u.setSenha(passwordFieldSenha.getText());
			
			PreparedStatement comando = conexao.prepareStatement(sql);

			comando.setString(1, u.getUsuario());
			comando.setString(2, u.getNome());
			comando.setString(3, u.getEmail());
			comando.setString(4, u.getTelefone());
			comando.setString(5, u.getSenha());
			comando.execute();

			System.out.println("Fechando Conexão...");

			comando.close();
			conexao.close();

			JOptionPane.showMessageDialog(null, "Usuário foi cadastrado com sucesso", "Info",
					JOptionPane.INFORMATION_MESSAGE);

		} else if (btnNewButtonCadastrar.getText().equals("Editar Dados")) {

			Connection conexao = FabricaConexao.criarConexao();

			usuarioEdicao.setNome(textFieldNome.getText());
			usuarioEdicao.setUsuario(textFieldUsuario.getText());
			usuarioEdicao.setEmail(textFieldEmail.getText());
			usuarioEdicao.setTelefone(textFieldTelefone.getText());
            usuarioEdicao.setSenha(passwordFieldSenha.getText());
			
			String sql = "UPDATE cadastroUsuarios SET USUARIO=?, NOME=?, EMAIL=?, TELEFONE=?, SENHA=? WHERE ID=?";

			PreparedStatement comando = conexao.prepareStatement(sql);
			
			comando.setString(1, usuarioEdicao.getUsuario());
			comando.setString(2, usuarioEdicao.getNome());
			comando.setString(3, usuarioEdicao.getEmail());
			comando.setString(4, usuarioEdicao.getTelefone());
			comando.setString(5, usuarioEdicao.getSenha());
			comando.setInt(6, usuarioEdicao.getId());
			comando.executeUpdate();

			ExibirMensagem("Dados Alterado");

			comando.close();
			conexao.close();

			usuarioEdicao = null;

		}

		atualizarListagem();

		textFieldNome.setText("");
		textFieldUsuario.setText("");
		textFieldEmail.setText("");
		textFieldTelefone.setText("");
		passwordFieldSenha.setText("");
		
	}

	private void exibirMensagemErro(String msg) {
		JOptionPane.showMessageDialog(null, msg, "ERRO", JOptionPane.ERROR_MESSAGE);

	}
}
