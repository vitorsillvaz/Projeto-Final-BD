create database Rede_Social;
use Rede_Social;

create table cadastroUsuarios(
     id int auto_increment not null primary key,
     usuario text,
     nome text,
     email text,
     telefone text,
     senha text
);
select *from cadastroUsuarios;