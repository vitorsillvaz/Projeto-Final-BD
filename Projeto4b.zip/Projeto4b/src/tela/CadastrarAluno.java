package tela;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import banco.FabricaConexao;
import dominio.Cliente;

public class CadastrarAluno extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldNome;
	private JTextField textFieldMatricula;
	private JTextField textFieldCurso;
	private JTextField textFieldTelefone;
	private JList listaAlunos;

	private Cliente alunoEdicao;
	private JButton btnNewButtonCadastrar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {

				try {
					CadastrarAluno frame = new CadastrarAluno();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastrarAluno() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 730, 458);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		textFieldNome = new JTextField();
		textFieldNome.setBounds(77, 46, 123, 20);
		contentPane.add(textFieldNome);
		textFieldNome.setColumns(10);

		textFieldMatricula = new JTextField();
		textFieldMatricula.setToolTipText("");
		textFieldMatricula.setColumns(10);
		textFieldMatricula.setBounds(77, 102, 123, 20);
		contentPane.add(textFieldMatricula);

		textFieldCurso = new JTextField();
		textFieldCurso.setColumns(10);
		textFieldCurso.setBounds(77, 159, 123, 20);
		contentPane.add(textFieldCurso);

		textFieldTelefone = new JTextField();
		textFieldTelefone.setColumns(10);
		textFieldTelefone.setBounds(77, 221, 123, 20);
		contentPane.add(textFieldTelefone);

		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setBounds(119, 28, 61, 14);
		contentPane.add(lblNewLabel);

		JLabel lblMatrcula = new JLabel("Matrícula");
		lblMatrcula.setBounds(119, 85, 61, 14);
		contentPane.add(lblMatrcula);

		JLabel lblCurso = new JLabel("Curso");
		lblCurso.setBounds(119, 142, 61, 14);
		contentPane.add(lblCurso);

		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setBounds(119, 203, 61, 14);
		contentPane.add(lblTelefone);

		btnNewButtonCadastrar = new JButton("Cadastrar Aluno");
		btnNewButtonCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					cadastrarAluno();
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}

			}
		});
		btnNewButtonCadastrar.setBounds(72, 268, 128, 38);
		contentPane.add(btnNewButtonCadastrar);

		JPanel panel = new JPanel();
		panel.setBorder(
				new TitledBorder(null, "Cadastro de Aluno", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(10, 11, 318, 362);
		contentPane.add(panel);
		panel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBorder(
				new TitledBorder(null, "Listagem de Aluno", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(338, 11, 366, 362);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 21, 346, 293);
		panel_1.add(scrollPane);

		listaAlunos = new JList();
		scrollPane.setViewportView(listaAlunos);

		JButton btnNewButtonExibir = new JButton("Exibir Dados");
		btnNewButtonExibir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Cliente alunoSelecionado = (Cliente) listaAlunos.getSelectedValue();

				String msg = "Nome: " + alunoSelecionado.getNome() + "\nMatricula: " + alunoSelecionado.getMatricula()
						+ "\nCurso : " + alunoSelecionado.getCurso() + "\nTelefone: " + alunoSelecionado.getTelefone();

				exibirMensagem(msg);
			}
		});
		btnNewButtonExibir.setBounds(4, 325, 114, 23);
		panel_1.add(btnNewButtonExibir);

		JButton Remover = new JButton("Remover Dados");
		Remover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					removerDados();
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		});
		Remover.setBounds(242, 325, 114, 23);
		panel_1.add(Remover);

		JButton btnNewButtonEditar = new JButton("Editar Dados");
		btnNewButtonEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				iniciarEdicaoAluno();
			}
		});
		btnNewButtonEditar.setBounds(117, 325, 125, 23);
		panel_1.add(btnNewButtonEditar);

		try {
			atualizarListagemAlunos();
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	protected void removerDados() throws ClassNotFoundException, SQLException {
		if (listaAlunos.getSelectedIndex() == -1) {
			exibirMensagemErro("Selecione o Usuário");
			return;
		}

		alunoEdicao = (Cliente) listaAlunos.getSelectedValue();

		Connection conexao = FabricaConexao.criarConexao();

		String sql = "DELETE FROM ALUNO WHERE ID_ALUNO = ?";

		PreparedStatement comando = conexao.prepareStatement(sql);
		comando.setInt(1, alunoEdicao.getId());
		comando.executeUpdate();

		exibirMensagem("Usuário deletado");

		atualizarListagemAlunos();

		comando.close();
		conexao.close();

	}

	protected void iniciarEdicaoAluno() {
		if (listaAlunos.getSelectedIndex() == -1) {
			exibirMensagemErro("Selecione o Usuário");
			return;
		}

		alunoEdicao = (Cliente) listaAlunos.getSelectedValue();

		textFieldNome.setText(alunoEdicao.getNome());
		textFieldMatricula.setText(alunoEdicao.getMatricula());
		textFieldCurso.setText(alunoEdicao.getCurso());
		textFieldTelefone.setText(alunoEdicao.getTelefone());

		btnNewButtonCadastrar.setText("Editar");

	}

	protected void cadastrarAluno() throws ClassNotFoundException, SQLException {

		if (textFieldNome.getText() == null || textFieldNome.getText().isEmpty()) {
			exibirMensagemErro("Nome não pode ser vazio");
			return;
		}

		if (textFieldMatricula.getText() == null || textFieldMatricula.getText().isEmpty()) {
			exibirMensagemErro("Matrícula não pode ser vazio");
			return;
		}

		if (textFieldCurso.getText() == null || textFieldCurso.getText().isEmpty()) {
			exibirMensagemErro("Curso não pode ser vazio");
			return;
		}

		if (textFieldTelefone.getText() == null || textFieldTelefone.getText().isEmpty()) {
			exibirMensagemErro("Telefone não pode ser vazio");
			return;
		}

		if (btnNewButtonCadastrar.getText().equals("Cadastrar Aluno")) {

			Connection conexao = FabricaConexao.criarConexao();

			JOptionPane.showMessageDialog(null, "Inserindo Dados");

			String sql = "INSERT INTO aluno (nome, matricula, curso, telefone) VALUES (?,?,?,?)";

			Cliente a = new Cliente();
			a.setNome(textFieldNome.getText());
			a.setMatricula(textFieldMatricula.getText());
			a.setCurso(textFieldCurso.getText());
			a.setTelefone(textFieldTelefone.getText());

			PreparedStatement comando = conexao.prepareStatement(sql);
			comando.setString(1, a.getNome());
			comando.setString(2, a.getMatricula());
			comando.setString(3, a.getCurso());
			comando.setString(4, a.getTelefone());
			comando.execute();

			exibirMensagem("Dados Cadastrados");

			comando.close();
			conexao.close();

		} else if (btnNewButtonCadastrar.getText().equals("Editar")) {

			alunoEdicao.setNome(textFieldNome.getText());
			alunoEdicao.setMatricula(textFieldMatricula.getText());
			alunoEdicao.setCurso(textFieldCurso.getText());
			alunoEdicao.setTelefone(textFieldTelefone.getText());

			exibirMensagem("Editando Dados");

			Connection conexao = FabricaConexao.criarConexao();

			String sql = "UPDATE ALUNO SET NOME=?, MATRICULA=?, CURSO=?, TELEFONE=? WHERE ID_ALUNO = ?";

			PreparedStatement comando = conexao.prepareStatement(sql);
			comando.setString(1, alunoEdicao.getNome());
			comando.setString(2, alunoEdicao.getMatricula());
			comando.setString(3, alunoEdicao.getCurso());
			comando.setString(4, alunoEdicao.getTelefone());
			comando.setInt(5, alunoEdicao.getId());
			comando.executeUpdate();

			exibirMensagem("Dados Alterados");

			comando.close();
			conexao.close();

			alunoEdicao = null;

		}

		btnNewButtonCadastrar.setText("Cadastrar Aluno");
		;

		atualizarListagemAlunos();

		textFieldNome.setText("");
		textFieldMatricula.setText("");
		textFieldCurso.setText("");
		textFieldTelefone.setText("");
	}

	private void exibirMensagemErro(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Erro", JOptionPane.ERROR_MESSAGE);
	}

	private void exibirMensagem(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Info", JOptionPane.INFORMATION_MESSAGE);
	}

	private void atualizarListagemAlunos() throws ClassNotFoundException, SQLException {

		Connection conexao = FabricaConexao.criarConexao();

		String sql = "SELECT * FROM ALUNO";

		PreparedStatement comando = conexao.prepareStatement(sql);

		System.out.println("Executando Comando...");

		ResultSet resultado = comando.executeQuery();

		List<Cliente> alunosCadastrados = new ArrayList<>();

		while (resultado.next()) {
			Cliente a = new Cliente();
			a.setId(resultado.getInt("id_aluno"));
			a.setNome(resultado.getString("nome"));
			a.setMatricula(resultado.getString("matricula"));
			a.setCurso(resultado.getString("curso"));
			a.setTelefone(resultado.getString("telefone"));

			alunosCadastrados.add(a);

		}

		DefaultListModel<Cliente> modelo = new DefaultListModel<>();

		for (int i = 0; i < alunosCadastrados.size(); i++) {
			Cliente a = alunosCadastrados.get(i);
			modelo.addElement(a);

		}

		listaAlunos.setModel(modelo);

		comando.close();
		conexao.close();
	}
}
