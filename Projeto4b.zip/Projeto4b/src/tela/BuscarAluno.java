package tela;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import banco.ClienteDao;
import dominio.Cliente;
import dominio.Produto;

public class BuscarAluno extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldNome;
	private JTextField textFieldMatricula;

	private JPanel panel_1;
	private JScrollPane scrollPane;

	private JButton btnBuscar;
	private JTable tabelaAlunos;
	private JTextField textFieldCurso;
	private JTextField textFieldTelefone;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastrarAluno frame = new CadastrarAluno();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BuscarAluno() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 773, 383);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Cadastrar Aluno", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(10, 29, 231, 267);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblNome = new JLabel("Nome: ");
		lblNome.setBounds(24, 28, 46, 14);
		panel.add(lblNome);

		JLabel lblMatricula = new JLabel("Matricula:");
		lblMatricula.setBounds(10, 62, 66, 14);
		panel.add(lblMatricula);

		JLabel lblCurso = new JLabel("Curso:");
		lblCurso.setBounds(10, 101, 46, 14);
		panel.add(lblCurso);

		textFieldNome = new JTextField();
		textFieldNome.setBounds(80, 25, 125, 20);
		panel.add(textFieldNome);
		textFieldNome.setColumns(10);

		textFieldMatricula = new JTextField();
		textFieldMatricula.setColumns(10);
		textFieldMatricula.setBounds(80, 59, 125, 20);
		panel.add(textFieldMatricula);

		btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					buscarAluno();
				} catch (ClassNotFoundException | SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnBuscar.setBounds(80, 192, 125, 23);
		panel.add(btnBuscar);

		textFieldCurso = new JTextField();
		textFieldCurso.setColumns(10);
		textFieldCurso.setBounds(80, 98, 125, 20);
		panel.add(textFieldCurso);

		textFieldTelefone = new JTextField();
		textFieldTelefone.setColumns(10);
		textFieldTelefone.setBounds(80, 143, 125, 20);
		panel.add(textFieldTelefone);

		JLabel lblTelefone = new JLabel("Telefone:");
		lblTelefone.setBounds(10, 146, 46, 14);
		panel.add(lblTelefone);

		panel_1 = new JPanel();
		panel_1.setBorder(
				new TitledBorder(null, "Listagem de Alunos", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(251, 38, 485, 295);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 26, 431, 215);
		panel_1.add(scrollPane);

		tabelaAlunos = new JTable();
		tabelaAlunos.setModel(new DefaultTableModel(new Object[][] {},
				new String[] { "Matrícula", "Nome", "Curso", "Telefone", "Disciplina", "CH" }));
		scrollPane.setViewportView(tabelaAlunos);

	}

	protected void buscarAluno() throws ClassNotFoundException, SQLException {

		ClienteDao dao = new ClienteDao();

		List<Cliente> alunosEncontrados = new ArrayList<Cliente>();

		alunosEncontrados = dao.buscarAlunos(textFieldNome.getText(), textFieldMatricula.getText(),
				textFieldCurso.getText(), textFieldTelefone.getText());

		DefaultTableModel modelo = new DefaultTableModel(
				new String[] { "Matrícula", "Nome", "Curso", "Telefone", "Disciplina", "CH" }, 0);

		for (int i = 0; i < alunosEncontrados.size(); i++) {

			Cliente aluno = alunosEncontrados.get(i);
	      			
			modelo.addRow(new String[] { aluno.getMatricula(), aluno.getNome(), aluno.getCurso(), aluno.getTelefone(),
					aluno.getDisciplina().getNomeDisciplina(),
					String.valueOf(String.valueOf(aluno.getDisciplina().getCargaHoraria())) });
		}

		tabelaAlunos.setModel(modelo);

	}

}
