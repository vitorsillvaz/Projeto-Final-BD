package banco;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import dominio.Produto;

public class DisciplinaDao {

	
	public void cadastrarDisciplina(Produto d) throws SQLException, ClassNotFoundException {
		Connection conexao = FabricaConexao.criarConexao();

	
		System.out.println("Inserindo dados...");

		String sql = " INSERT INTO disciplina (nome,ch,id_aluno) VALUES (?,?,?) ";

		PreparedStatement comando = conexao.prepareStatement(sql);
		comando.setString(1, d.getNomeDisciplina());
		comando.setInt(2, d.getCargaHoraria());
		comando.setInt(3, d.getAluno().getId());
		comando.execute();

		System.out.println("Fechando Conexão");

		comando.close();
		conexao.close();

		JOptionPane.showMessageDialog(null, "Disciplina Cadastrada com Sucesso");
		
	}

	
	public List<Produto> buscarAlunoPeloNome(String nome) throws SQLException, ClassNotFoundException {

		Connection conexao = FabricaConexao.criarConexao();

		String sql = " SELECT * FROM disciplina WHERE 1 = 1 ";

		if (nome != null && !nome.isEmpty()) {
			sql += " AND upper(nome) LIKE ? ";
		}

		PreparedStatement comando = conexao.prepareStatement(sql.toString());
		int i = 1;

		if (nome != null && !nome.isEmpty()) {
			comando.setString(i++, "%" + nome.toUpperCase() + "%");
		}

		ResultSet resultado = comando.executeQuery();

		List<Produto> disciplinasCadastrados = new ArrayList<>();

		while (resultado.next()) {
			Produto d = new Produto();
			d.setIdDisciplina(i);
			d.setNomeDisciplina(resultado.getString("nome"));
			d.setCargaHoraria(resultado.getInt("ch"));

			disciplinasCadastrados.add(d);
		}

		return disciplinasCadastrados;

	}
}
